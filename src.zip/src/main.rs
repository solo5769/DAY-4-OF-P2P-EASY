use yew::{function_component, html, Html, use_state, Callback};
use wasm_bindgen::{prelude::*, JsValue, JsCast};
use wasm_bindgen_futures::JsFuture;
use log::info;

#[function_component(App)]
fn app() -> Html {
    let connected_account = use_state(|| String::new());
    let status_message = use_state(|| String::from("🔌 Wallet not connected"));

    let connect_wallet = {
        let connected_account = connected_account.clone();
        let status_message = status_message.clone();

        Callback::from(move |_| {
            info!("🔘 Connect Wallet clicked");

            let connected_account = connected_account.clone();
            let status_message = status_message.clone();

            wasm_bindgen_futures::spawn_local(async move {
                let window = web_sys::window().expect("No window available");
                let ethereum = js_sys::Reflect::get(&window, &JsValue::from_str("ethereum"))
                    .unwrap_or(JsValue::UNDEFINED);

                info!("🔍 window.ethereum: {:?}", ethereum);

                if ethereum.is_undefined() || ethereum.is_null() {
                    status_message.set("⚠️ MetaMask not found.".to_string());
                    return;
                }

                let method_obj = js_sys::Object::new();
                js_sys::Reflect::set(
                    &method_obj,
                    &JsValue::from_str("method"),
                    &JsValue::from_str("eth_requestAccounts"),
                ).unwrap();

                let request_fn = js_sys::Reflect::get(&ethereum, &JsValue::from_str("request")).unwrap();
                let request_function = request_fn.unchecked_ref::<js_sys::Function>();
                let promise = request_function.apply(&ethereum, &js_sys::Array::of1(&method_obj)).unwrap();

                match JsFuture::from(js_sys::Promise::from(promise)).await {
                    Ok(accounts) => {
                        let array = js_sys::Array::from(&accounts);
                        let first_account = array.get(0);
                        info!("✅ Account fetched: {:?}", first_account);

                        if let Some(account_str) = first_account.as_string() {
                            connected_account.set(account_str.clone());
                            status_message.set("✅ Wallet connected!".to_string());
                        } else {
                            status_message.set("❌ Could not extract account.".to_string());
                        }
                    }
                    Err(err) => {
                        let msg = err.as_string().unwrap_or("Unknown error".to_string());
                        status_message.set(format!("❌ Error: {}", msg));
                        info!("❌ Wallet connection error: {:?}", err);
                    }
                }
            });
        })
    };

    html! {
        <main class="flex items-center justify-center min-h-screen bg-gradient-to-tr from-gray-100 to-gray-200 px-4">
            <section class="bg-white shadow-xl rounded-xl p-8 max-w-md w-full space-y-6 text-center">
                <h1 class="text-3xl font-extrabold text-blue-700 tracking-tight">{"EVM Wallet Connector"}</h1>

                <button
                    onclick={connect_wallet}
                    class="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 hover:scale-105 hover:shadow-lg transform transition duration-200"
                >
                    {"🔗 Connect Wallet"}
                </button>

                <p class="text-lg font-medium text-gray-800">{ (*status_message).clone() }</p>

                {
                    if !connected_account.is_empty() {
                        html! {
                            <div class="mt-2 text-sm text-gray-600">
                                <span class="font-semibold text-gray-700">{"Connected address: "}</span>
                                <code class="bg-gray-100 px-2 py-1 rounded">{ (*connected_account).clone() }</code>
                            </div>
                        }
                    } else {
                        html! {}
                    }
                }
            </section>
        </main>
    }
}

fn main() {
    wasm_logger::init(wasm_logger::Config::default());
    console_error_panic_hook::set_once();
    yew::Renderer::<App>::new().render();
}
